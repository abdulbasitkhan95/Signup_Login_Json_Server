import './App.css';
import Routing from "./config/router";

function App() {
  return (
    <Routing/>
  );
}

export default App;
