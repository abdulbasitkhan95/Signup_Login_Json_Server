export const BASE_PATH = 'http://localhost:3000/'
export const TIME_OUT = 3000